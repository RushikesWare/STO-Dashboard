import React from 'react'

function NoPageFound() {
  return (
    <h2>No Page Found..!</h2>
  )
}

export default NoPageFound