import React from 'react'

function AllInOneDashboard() {
  return (
    <div>AllInOneDashboard</div>
  )
}

export default AllInOneDashboard